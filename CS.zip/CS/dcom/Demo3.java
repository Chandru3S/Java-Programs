package dcom;

import com.CS1;

public class Demo3 {

	public static void main(String[] args) {
		
		CS1 c = new CS1();
		System.out.println(c.a);

	}

}
