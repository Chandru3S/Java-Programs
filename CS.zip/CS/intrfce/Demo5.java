package intrfce;

import java.io.Serializable;

public class Demo5 {	
	class A
	{
		
	}
}
