package love;

public class Demo8 {

}
