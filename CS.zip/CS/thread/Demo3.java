package thread;

public class Demo3 extends sendsms{

	public static void main(String[] args) {
	
		//Demo3 d = new Demo3();
		
		sendsms sms = new sendsms();
		
		sms.init ();
	}

}
