package exception;

public class NosufficientBal extends Exception {
	
	public NosufficientBal(String msg) {
		
		super(msg);
	}
	
}
