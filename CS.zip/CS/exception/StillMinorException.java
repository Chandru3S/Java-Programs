package exception;

public class StillMinorException extends Exception {
	
	public StillMinorException(String msg)
	{
		super(msg);
	}

}
