package cs;

public class veeru {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     String s1 = "JAVA";
     String s2 = "PYTHON";
     String s3 = s1+s2;
     String s4 =  s2+s1;
     
     if(s1==s2)
     {
    	 System.out.println("reference is equle");
     }
	else
	{
		System.out.println("reference is not equle");
	}
	}   
}
