package cs;

public class Asci {

	public static void main(String[] args) {
		for(int i=1;i<150;i++) {
			System.out.println(i+"----------"+(char)i);
		}
	}

}
