package logic;

public class Demo5 {

	public static void main(String[] args) {
		
		char a = 'e'-32;
		
		System.out.println(a);
		
	}
}
