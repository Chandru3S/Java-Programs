package com;

public class CS2 {

	public static void main(String[] args) {

//		CS2 c = new CS2();
		CS1 c = new CS1();
		System.out.println(c.a);
		
	}

}
