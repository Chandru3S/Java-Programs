package com;

public class CS1 {
	
//	private int a =10;
//	protected int a =10;
//	int a =10;
	public int a =10;
	
	public static void main(String[] args) {
		
		CS1 c = new CS1();
		System.out.println(c.a);
		
	}

}
