package s;

public class Demo3 {
	
//	static
//	{
//		System.out.println("I hate You");
//	}
//
	public static void main(String[] args) {
		
//		System.out.println("Hello, baby");
		
//		Demo1.Disp();
		
//		System.out.println("\nBut I Love you");	
		
		
		
		U u = new U();
		System.out.println(u.accountNo+"\n\n"+u.password);
		
		
	}
}

class U
{
//	private int accountNo =4505;
//	private int password= 319;
	
	
	private int accountNo;
	private int password;
}

























//
//class Demo1
//{
//	 static int a;
//	 static int b;
//	 static String c;
//	 
//	 static
//	 {
//		 a=1;
//		 b=43;
//		 c="CS";
//	 }
//	 
//	 static void Disp()
//	 {
//	 	System.out.println(a+""+b+"\n"+c);
//	 }
//}


